// Loaded by views-view--related-content.tpl.php
(function ($, Drupal, window, document, undefined) {

  $(window).load(function () {

    var carouselHt = 0;
    $(".related-content__carousel-item").each(function() {
      var itemHt = $(this).height();
      //console.log('itemHt = ' + itemHt);
      if (itemHt > carouselHt) {
        carouselHt = itemHt;
      }
    });
    
    $(".related-content__carousel-item").height(carouselHt);
    
    //console.log('carouselHt = ' + carouselHt + 'px');
  
    $("#related-content__carousel").carouFredSel({
      width: "100%",
      height: carouselHt,
      circular: true,
      infinite: true,
      auto: false,
      swipe: true,
      items: {
        visible: "variable",
        width: 200,
        height: carouselHt
      },
      scroll: {
        fx: "directscroll"
      },
      next: "#related-content__next-inner",
      prev: "#related-content__prev-inner"
    });
    
    $(".view-related-content").css("visibility", "visible");
  });
})(jQuery, Drupal, this, this.document);