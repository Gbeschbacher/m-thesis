/**
 * @file
 * A JavaScript file for the theme.
 *
 * In order for this JavaScript to be loaded on pages, see the instructions in
 * the README.txt next to this file.
 */

function scrollToElement(elm, time, off) {
  (function($) {
    time = typeof(time) != "undefined" ? time : 1000;
    off = typeof(off) != "undefined" ? off : 0;
    elm = typeof(elm) == "object" ? elm : 
          typeof(elm) == "string" ? $(elm) : "";
    if (elm && elm.length > 0) {
      var offset = elm.offset();
      var offset_top = Math.ceil(offset.top + off);
      $("html, body").animate({ scrollTop: offset_top }, time);
    }
  })(jQuery);
}

function resizeColorBox(ht) {
  // Resize the colorbox based on the height of the content.
  (function($) {  // $ = jQuery
    if ($("#colorbox").is(":visible")) {
      $.colorbox.resize({ innerHeight:ht });
    }
  })(jQuery);
}

function closeColorBox() {
  // Close the colorbox.
  (function($) {  // $ = jQuery
    if ($("#colorbox").is(":visible")) {
      $.colorbox.close();
    }
  })(jQuery);
}


// JavaScript should be made compatible with libraries other than jQuery by
// wrapping it with an "anonymous closure". See:
// - http://drupal.org/node/1446420
// - http://www.adequatelygood.com/2010/3/JavaScript-Module-Pattern-In-Depth
(function ($, Drupal, window, document, undefined) {

  $("html").removeClass("no-js").addClass("has-js");

  $(function() {
    
    /**
     * Responsive iFrames
     * Setup iframe to be response by removing the width/height form the iframe and wrapping the iframe in a responsive container.
     */
    $(".responsive-iframe-unprocessed").each(function() {
      var iframe = $(this).find("iframe");
      var iframeWidth = iframe.width();
      var iframeHeight = iframe.height();
      var paddingTop = (Math.ceil((iframeHeight / iframeWidth) * 100000) / 1000) + "%";
      iframe.wrap('<div class="responsive-iframe__outer" style="max-width: ' + iframeWidth + 'px; max-height: ' + iframeHeight + 'px;"><div class="responsive-iframe__inner" style="padding-top:' + paddingTop + ';"></div></div>');
      $(this).removeClass("responsive-iframe-unprocessed")
             .addClass("responsive-iframe-processed");
    });
    
    jQuery(function($) {
      // setup iframe to be response by removing the width/height form the iframe and wrapping the iframe in a responsive container
      var presentation_iframe = $(".field-presentation-embed-code iframe");
      presentation_iframe.each(function() {
        $(this).wrap('<div class="responsive-iframe-wrapper" style="padding-top:' + (($(this).height() / $(this).width()) * 100) + '%">');
        $(this).removeAttr('height').removeAttr('width');
      }); 
    });
      
    /**
  	 * Horizontal rules.
  	 * Nest the <hr> element into a div container for customization via CSS
  	 * unless it has already been nested in a div with "horz-rule" class name.
  	 */
    $("hr").each(function() {
      var parentNode = $(this).parent("div.horz-rule");
      if (parentNode.length == 0) {
        $(this).wrap('<div class="horz-rule" />');
      }
    });
    
    /**
  	 * Link target.
  	 * Add target="_blank" attribute to select links to external sites and pdfs.
  	 */
    //$("ul.menu a[href^='http'], ul.menu a[href$='pdf']").attr("target", "_blank");
    $("a[href^='http']").each(function () {
      // Open the link in a new window except if the "href" starts with the current site's domain.
      var href = $(this).attr("href");
      if (href.indexOf("http://" + location.hostname) !== 0) {
        $(this).attr("target", "_blank");
      }
    });
    $("a[href$='.pdf']").each(function () {
      // Open the PDF in a new window only if the "target" attribute is not already defined.
      var target = $(this).attr("target");
      if (typeof target == "undefined") {
        $(this).attr("target", "_blank");
      }
    });
    
    /**
     * Search form.
     *
     * Hide the field label when the user begins to type a keyword in the search form input field.
     */
    $(".navigation__search .google-cse-search-form__input").val("").keydown(function(e) {
      $(this).siblings(".google-cse-search-form__label").fadeOut("fast");
    });
    $(".navigation__search .google-cse-search-form__keyword-field").width("auto");
    var searchKeywordWidth = $(".navigation__search .google-cse-search-form__keyword-field").innerWidth();
    $(".navigation__search .google-cse-search-form__keyword-field").width(0);
    $(".navigation__search .google-cse-search-form").hover(
      function (e) {
        $(".navigation__search .google-cse-search-form__keyword-field").stop().animate({ width: searchKeywordWidth }, 200, "easeInOutExpo", function() {
          $(this).find(".google-cse-search-form__input").focus();
        });
      }, 
      function (e) {
        $(".navigation__search .google-cse-search-form__keyword-field").stop().animate({ width: 0 }, 200, "easeInOutExpo");
      }
    );
        
    /**
  	 * Menus.
  	 */
    $(".header__menu .menu .menu__item-level-1.expanded, .navigation__secondary-menu .menu .menu__item-level-1.expanded").hover(
      function (e) {
        // Rotate the stack order so that the submenu appears on top of all other submenus.
        $(this).css("zIndex", 2).children(".menu").each(function() {
          $(this).hide();
          
          // Reset the height to auto to correct how jQuery calculates the height of the menu when partially open.
          $(this).css("height","auto");
          
          // Slide the menu down/open; stop any active or queue animations.
          $(this).stop(true).slideToggle(200);
        });
      }, 
      function (e) {
        // Rotate the stack order so that the submenu appears behind all submenus.
        $(this).css("zIndex", 1).children(".menu").each(function() {
          // Slide the menu up/closed; stop any active or queue animations.
          $(this).stop(true).slideToggle(200);
        });
      }
    ).children(".menu").hide();
    
    $(".navigation__secondary-menu-collapsed").hover(
      function (e) {
        $(this).find(".block__content > .menu").each(function() {
          $(this).hide();
          
          // Reset the height to auto to correct how jQuery calculates the height of the menu when partially open.
          $(this).css("height","auto");
          
          // Slide the menu down/open; stop any active or queue animations.
          $(this).stop(true).slideToggle(200);
        });
      }, 
      function (e) {
        $(this).find(".block__content > .menu").each(function() {
          // Slide the menu up/closed; stop any active or queue animations.
          $(this).stop(true).slideToggle(200);
        });
      }
    ).find(".block__content > .menu").hide();
    
    // Note: This event handler will be triggered automatically on DOM ready (see below).
    $(window).resize(function() {
      var navigationWt = $("#navigation").width();
      var mainMenuWt = $(".navigation__main-menu .block__content").outerWidth();
      var secondaryMenuOffsetRt = parseInt($(".navigation__secondary-menu").css("right"));
      var availableWt = navigationWt - mainMenuWt - secondaryMenuOffsetRt;
      
      //console.log("\n\n");
      //console.log("navigationWt = " + navigationWt);
    	//console.log("mainMenuWt = " + mainMenuWt);
    	//console.log("secondaryMenuWt = " + secondaryMenuWt);
    	//console.log("secondaryMenuOffsetRt = " + secondaryMenuOffsetRt);
    	//console.log("availableWt = " + availableWt);
    	
    	var showMore = false; 
    	
  	  // Trim the menu.
  	  $($(".navigation__secondary-menu .menu__item-level-1").get().reverse()).show().each(function(ix) {
  	    secondaryMenuWt = $(".navigation__secondary-menu").width();
  	    //console.log("secondaryMenuWt = " + secondaryMenuWt);
  	    
  	    if (secondaryMenuWt > availableWt) {
  	      //console.log("Hide = " + $(this).text());
  	      $(this).hide();
  	      
  	      $($($(".navigation__secondary-menu-collapsed .menu__item-level-1").get().reverse()).eq(ix)).show();
  	      
  	      showMore = true;
  	    }
  	    else {
  	      //console.log("Show = " + $(this).text());
  	      $(this).show();
  	      
  	      $($($(".navigation__secondary-menu-collapsed .menu__item-level-1").get().reverse()).eq(ix)).hide();
  	    }
  	  });
  	  
  	  if (showMore) {
  	    $(".navigation__secondary-menu-collapsed").show();
  	  }
  	  else {
  	    $(".navigation__secondary-menu-collapsed").hide();
  	  }
    	
    });
    
    // Wrap subcategories in scrollpane when needed.
    $(".main-menu__subcategories").each(function() {
      if ($(this).height() > parseInt($(this).css("min-height"))) {
        $(this).addClass("main-menu__subcategories-scrollable").wrapInner('<div class="main-menu__scrollpane"></div>');
      }
    });
    var mainMenuScrollpane = $(".main-menu__scrollpane");
    
    // Get the combined height of the first 10 items in the subcategories menu. The combined height may not exceed 400px.
    var scrollpaneMaxHt = 0;
    mainMenuScrollpane.find(".main-menu__subcategories-item").each(function(ix) {
      if (ix < 10) {
        if (scrollpaneMaxHt < parseInt(mainMenuScrollpane.css("max-height"))) {
          scrollpaneMaxHt += $(this).outerHeight();
        }
        else {
          return false;
        }
      }
      else {
        return false;
      }
    });
    mainMenuScrollpane.css("max-height", scrollpaneMaxHt - 5);
    
    // Initialize the subcategories menu scrollpane.
    mainMenuScrollpane.bind(
        "jsp-scroll-y",
        function(event, scrollPositionY, isAtTop, isAtBottom) {
          mainMenuScrollpane.find(".main-menu__subcategories-item a").each(function() {
            var pos = $(this).position();
            var top = pos.top - scrollPositionY;
            if (top == 0) {
              $(this).attr("class","main-menu__color3");
            }
            else if (top <= ((scrollpaneMaxHt / 10) * 1)) {
              $(this).attr("class","main-menu__color2");
            }
            else if (top > ((scrollpaneMaxHt / 10) * 8)) {
              $(this).attr("class","main-menu__color4");
            }
            else if (top > ((scrollpaneMaxHt / 10) * 7)) {
              $(this).attr("class","main-menu__color3");
            }
            else if (top > ((scrollpaneMaxHt / 10) * 6)) {
              $(this).attr("class","main-menu__color2");
            }
            else {
              $(this).attr("class","main-menu__color1");
            }
          });
        }
      ).jScrollPane({
      verticalDragMinHeight: 24,
      verticalDragMaxHeight: 24,
    });
    
    mainMenuScrollpane.find(".main-menu__subcategories-item a").each(function(ix) {
      var pos = $(this).position();
      var top = pos.top;
      if (top == 0) {
        $(this).attr("class","main-menu__color3");
      }
      else if (top <= ((scrollpaneMaxHt / 10) * 1)) {
        $(this).attr("class","main-menu__color2");
      }
      else if (top > ((scrollpaneMaxHt / 10) * 8)) {
        $(this).attr("class","main-menu__color4");
      }
      else if (top > ((scrollpaneMaxHt / 10) * 7)) {
        $(this).attr("class","main-menu__color3");
      }
      else if (top > ((scrollpaneMaxHt / 10) * 6)) {
        $(this).attr("class","main-menu__color2");
      }
      else {
        $(this).attr("class","main-menu__color1");
      }
    });
    
    var mainMenuHt = $(".navigation__main-menu").height();  // Height of main menu.
    var subMenuHt = 0;  // Height of submenu.
    var mainMenuSubcategories = $(".main-menu__subcategories");
    mainMenuSubcategories.hide();
    // Note: This event handler will be triggered automatically on DOM ready (see below).
    $(window).resize(function() {
      mainMenuHt = $(".navigation__main-menu").height();
      subMenuHt = 0;
      mainMenuSubcategories.each(function() {
        $(this).height("auto");
        if ($(this).innerHeight() > subMenuHt) {
          subMenuHt = $(this).innerHeight();
        }
      }).innerHeight(subMenuHt);
    });
    
    //$(".navigation__main-menu").height(mainMenuHt).find(".block__content").hover(
    $(".navigation__main-menu").find(".block__content").hover(
      function (e) {
        $(".navigation__main-menu").addClass("is-open").stop().animate({ height: subMenuHt + mainMenuHt }, 400, "easeInOutExpo");
        
        // Stop the home slideshow on hover/open.
        if ($("#block-views-home-slideshow-block").length > 0) {
          $("#home-slideshow__overlay").fadeIn("fast");
          var isStopped = $("#home-slideshow__inner").triggerHandler("isStopped");
          if (!isStopped) {
            //console.log('stop');
            $("#home-slideshow__inner").trigger("stop");
            $("#home-slideshow__next-outer").fadeOut();
            $("#home-slideshow__prev-outer").fadeOut();
            $("#home-slideshow__pager-outer").fadeOut();
          }
        }
      }, 
      function (e) {
        $(".navigation__main-menu").removeClass("is-open").stop().animate({ height: mainMenuHt }, 400, "easeInOutExpo");
        
        $(".main-menu__categories-item-active").removeClass("main-menu__categories-item-active");
        $(".main-menu__subcategories-item-active").removeClass("main-menu__subcategories-item-active");
        
        // Resume the home slideshow on hover/open.
        if ($("#block-views-home-slideshow-block").length > 0) {
          $("#home-slideshow__overlay").fadeOut("fast");
          var isStopped = $("#home-slideshow__inner").triggerHandler("isStopped");
          // The slideshow should stop when scrolled past 100px.
          if (isStopped && $(window).scrollTop() <= 100) {
            $("#home-slideshow__inner").trigger("play", true);
            $("#home-slideshow__next-outer").fadeIn();
            $("#home-slideshow__prev-outer").fadeIn();
            $("#home-slideshow__pager-outer").fadeIn();
          }
        }
      }
    );
    
    // Activate the category and display the subcategories when hovering over categories.
    $(".main-menu__categories-item").mouseover(function() {
      // Hide any visible subcategories.
      $(".main-menu__subcategories:visible").hide();
      // Activate the category and show its subcategories.
      $(this).addClass("main-menu__categories-item-active").find(".main-menu__subcategories").show();
    });
    
    // Activate the subcategory and display the submenu when hovering over subcategories.
    $(".main-menu__subcategories-item").mouseover(function() {
      // Deactivate any active subcategories.
      $(".main-menu__subcategories-item-active").removeClass("main-menu__subcategories-item-active");
      // Activate the subcategory.
      $(this).addClass("main-menu__subcategories-item-active");
      
      // Hide any visible submenus.
      $(".main-menu__submenu-item:visible").hide();
      // Get the subcategory's unique id.
      var id = $(this).attr("id").match(/\d+$/g)[0];
      // Get the corresponding submenu.
      $("#main-menu__submenu-item-" + id).show();
    });
    
    // Toggle the display of the submenu on hover.
    $(".main-menu__categories-item > a").mouseover(function() {
      var parent = $(this).parent();
      // Deactivate currently active category.
      $(".main-menu__categories-item-active").removeClass("main-menu__categories-item-active");
      // Hide any visible submenus.
      $(".main-menu__submenu-item:visible").hide();
      // Get the category's unique id.
      var id = parent.attr("id").match(/\d+$/g)[0];
      // Get the corresponding submenu.
      $("#main-menu__submenu-item-" + id).show();
      // Deactivate any active subcategories.
      $(".main-menu__subcategories-item-active").removeClass("main-menu__subcategories-item-active");
      // Activate the first ("All") subcategory.
      parent.find(".main-menu__subcategories-item-first").addClass("main-menu__subcategories-item-active");
    });
        
    /**
     * Filter content.
     */
    $(".filter-content").hover(
      function (e) {
        $(this).children(".filter-content__menu").each(function() {
          $(this).hide();
          
          // Reset the height to auto to correct how jQuery calculates the height of the menu when partially open.
          $(this).css("height","auto");
          
          // Slide the menu down/open; stop any active or queue animations.
          $(this).stop(true).slideToggle(200);
        });
      }, 
      function (e) {
        $(this).children(".filter-content__menu").each(function() {
          // Slide the menu up/closed; stop any active or queue animations.
          $(this).stop(true).slideToggle(200);
        });
      }
    ).find(".filter-content__menu").hide();
    
        
    /**
     * Mobile menu.
     */
    if ($("html").hasClass("lt-ie9") == false) {
      $("nav#mobile-menu")
        .mmenu({
          "offCanvas": {
            "position": "right"
          }
        })
        .on(
          "opened.mm",
          function() {
            $(".mobile-menu-button__open-icon").hide();
            $(".mobile-menu-button__close-icon").show();
          }
        )
        .on(
          "closed.mm",
          function() {
            $(".mobile-menu-button__close-icon").hide();
            $(".mobile-menu-button__open-icon").show();
          }
        );
    }
          
    /**
     * Video lightbox.
     */
    $(".video-lightbox").click(function (e) {
      e.preventDefault();
      var nodePath = $(this).attr("href");
      // alert("/lightbox/video?path=" + encodeURIComponent(nodePath));
      
      $.colorbox({
        iframe:        true, 
        href:          "/lightbox/video?path=" + encodeURIComponent(nodePath),
        width:         "95%",
        height:        "95%",
        initialWidth:  "50%",
        initialHeight: "50%",
        maxWidth:      "960px",
        scrolling:     false,
        fastIframe:    false,
        opacity:       0.8
      });
    });
          
    /**
     * CTA links with Google Analytics Event Tracking.
     */
    $(".ga-cta").click(function (e) {
      var pageTitle = $(this).closest(".node").find(".field-name-title").text();
      if (pageTitle == "") {
        pageTitle = $("#page-title").text();
      }
      
      if ($(this).hasClass("image")) {
        _gaq.push(['_trackEvent', 'CTA', 'Click-Image', pageTitle]);
      }
      else if ($(this).hasClass("button")) {
        _gaq.push(['_trackEvent', 'CTA', 'Click-Button', pageTitle]);
      }
      else {
        _gaq.push(['_trackEvent', 'CTA', 'Click-Link', pageTitle]);
      }
    });
    
    // Trigger all resize event handlers.
    $(window).resize();
    
  });  // end: on document ready scripts
})(jQuery, Drupal, this, this.document);