//<![CDATA[
      var usasearch_config = { siteHandle:"usgs" };

      var script = document.createElement("script");
      script.type = "text/javascript";
      script.src = "https://search.usa.gov/javascripts/remote.loader.js";
      document.getElementsByTagName("head")[0].appendChild(script);

//]]>

