$(document).ready(function(){

	$("a").click(function(){
		var url = $(this).attr("href");
		if ( url.search(/^http:\/\/indiemapper.com/) != -1 ){
			window.open(url, "_blank", 'width=710');
			return false;
		} else {
			return true;
		}
	});

});